package com.ayantsoft.serv;

public class Emp1 {

	private Integer Id;
	private String name;
	
	
	
}
