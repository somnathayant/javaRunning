package com.ayantsoft.myspring.empcontroller;


import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class EmpController {

	
	 @RequestMapping("/")  
	    public ModelAndView welcome() {  
	   	 
		 ModelAndView mv=new ModelAndView();
		 mv.setViewName("welcome");
		 return mv;
		}  
	
		 
}
