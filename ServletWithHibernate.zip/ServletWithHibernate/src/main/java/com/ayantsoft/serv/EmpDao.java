package com.ayantsoft.serv;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;
import org.hibernate.sql.JoinType;

import com.ayantsoft.hibernate.pojo.Address;
import com.ayantsoft.hibernate.pojo.Emp;
import com.ayantsoft.hibernate.util.HbernateUtil;




public class EmpDao implements Serializable{

	
	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 662790234699350128L;

	public static int save(Emp e,Address add){
		Integer status=0;
		System.out.println("okkk");;
		Session session=null;
		try{
			session=HbernateUtil.openSession();
			session.beginTransaction();
			
			session.save(add);
			
			status=(Integer)session.save(e);
			
			status=1;
		System.out.println("okkk");;	
		session.getTransaction().commit();
		}
		
		catch(Exception ex){ex.printStackTrace();
		session.getTransaction().rollback();
		}
		
		finally{
			session.close();
		}
		
		return status;
	}
	
	public static int update(Emp e){
		int status=0;
		Session session=null;
		try{
			session=HbernateUtil.openSession();
			session.beginTransaction();
			//session.saveOrUpdate(e.getAddress());
			//session.saveOrUpdate(e);
			
			
			Query addressQuery = session.createQuery(""
					+ "UPDATE "
					+ "Address "

					+ "SET "						
					+ "city = :city "
					+ "WHERE "
					+ "id = :id ");

			addressQuery.setParameter("city",e.getAddress().getCity())
				.setParameter("id",e.getAddress().getId())
			.executeUpdate();
			
			Query employeeQuery = session.createQuery(""
					+ "UPDATE "
					+ "Emp "

					+ "SET "						
					+ "name = :name, "
					+ "password = :password, "
					+ "email = :email, "
					+ "address = :address "

					+ "WHERE "
					+ "id = :id ");

			employeeQuery.setParameter("name",e.getName())
			.setParameter("password",e.getPassword())
			.setParameter("email",e.getEmail())
			.setParameter("address",e.getAddress())
			.setParameter("id",e.getId())
			.executeUpdate();
			
			
			status=1;
		session.getTransaction().commit();}catch(Exception ex){ex.printStackTrace();
		status=0;
		session.getTransaction().rollback();}
		finally{
			session.close();
		}
		return status;
	}
	
	public static int delete(int id){
		int status=0;
		Session session=null;
		Emp e=new Emp();
		try{
			session=HbernateUtil.openSession();
			session.beginTransaction();
			
		session.getTransaction().commit();	}catch(Exception ex){ex.printStackTrace();}
		finally{
			session.close();
		}
		return status;
	}
	
	public static Emp getEmployeeById(Integer id){
		Emp e=new Emp();
		Emp e1=new Emp();
		Session session=null;
		try{
			session=HbernateUtil.openSession();
			/*Criteria criteria = session.createCriteria(Emp.class, "EMP")
					.createAlias("EMP.address", "Add")
					.add(Restrictions.eq("EMP.id",id));
					
					e =(Emp) criteria.list().get(0);
		*/	
			
			String hql = "From  Emp EMP JOIN FETCH EMP.address ADD where EMP.id =:id";
			Query query = session.createQuery(hql);
			query.setParameter("id",id);
			e=(Emp)query.uniqueResult();
            
			/*e1=(Emp)session.load(Emp.class,id);
			System.out.println(e1.getEmail());
			System.out.println(e1.getName());
*/			
		}catch(Exception ex){ex.printStackTrace();}
		finally{
			session.close();
		}
		return e;
	}
	
	public static List<Emp> getAllEmployees(){
		List<Emp> employees=new ArrayList<Emp>();
		Session session=null;
		try{
			//inner join of criteria
			session=HbernateUtil.openSession();
			
			/*Criteria criteria = session.createCriteria(Emp.class, "EMP")
					.createAlias("EMP.address", "Address")
					
					.add(Restrictions.ge("EMP.id",new Integer(20)));
			employees =criteria.list();
			
		*/	
			/*Criteria criteria = session.createCriteria(Emp.class, "EMP")
					.createAlias("EMP.address", "Address");
					
			employees =criteria.list();
			*/
			
			
			
			//inner join in hql
			session=HbernateUtil.openSession();
				
			
			String hql = "FROM Emp EMP "
					+ "JOIN FETCH  EMP.address ADD where EMP.id <=:id";
			
					
			Query query = session.createQuery(hql);
			query.setParameter("id",new Integer(14));
			
			employees = ((List<Emp>) query.list());

		
		}catch(Exception e){e.printStackTrace();}
		finally{
			session.close();
		}
		return employees;
	}
}
